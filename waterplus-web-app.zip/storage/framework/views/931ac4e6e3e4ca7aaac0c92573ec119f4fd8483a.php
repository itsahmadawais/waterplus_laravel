

<?php $__env->startSection('content'); ?>
<div class="padding">
  <div class="box">
    <div class="box-header">
      <h2>Sectors</h2>
    </div>
    <div class="table-responsive">
      <table id="DataTables" ui-jp="dataTable" class="table table-striped b-t b-b">
        <thead>
          <tr>
            <th  style="width:80%">Title</th>
            <th  style="width:20%" class="nosort"></th>
          </tr>
        </thead>
        <tbody>
        	<?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($sector->sector_title); ?></td>
            <td>
                <?php if($sector->customers==null || count($sector->customers)<=0): ?>
                <form method="POST" action="<?php echo e(url('sectors/'.$sector->id)); ?>" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="md-btn md-raised red"><i class="fa fa-trash"></i></button>
                </form>
                <?php endif; ?>
                <button class="md-btn md-raised blue"><i class="fa fa-pencil" onclick="moveToScreen('<?php echo e(url('sectors/'.$sector->id)); ?>')"></i></button>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ButtSahab\waterplus-web-app\resources\views/pages/sectors/all.blade.php ENDPATH**/ ?>