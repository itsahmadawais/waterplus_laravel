

<?php $__env->startSection('content'); ?>
<div class="padding">
  <div class="row">
    <div class="col-md-6 mx-auto">
      <div class="box">
        <div class="box-header">
          <h2>Add Purchase Record</h2>
        </div>
        <div class="box-divider m-0"></div>
        <div class="box-body">
          <form id="form-purchase" role="form" method="POST" action="<?php echo e(url('purchases')); ?>">
            <?php echo csrf_field(); ?>

            

            <div class="form-group">
              <label for="sector_id">Select Sector</label>
              <select id="sector_id" class="form-control select2" ui-jp="select2" ui-options="{theme: 'bootstrap'}" name="sector_id" required>
                <option value="" selected="">Select Sector</option>
                <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($sector->id); ?>"><?php echo e($sector->sector_title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>


            

            <div class="form-group">
              <label for="user_id">Select Customer</label>
              <select id="user_id" class="form-control select2" ui-jp="select2" ui-options="{theme: 'bootstrap'}" name="user_id" disabled="" required="">
              </select>
            </div>

            <?php if(count($customers)<=0): ?>
            <div class="text-right">
              <a href="<?php echo e(url('customers/add')); ?>" class="btn primary btn-block m-b">Add Customer</a>
            </div>
            <?php endif; ?>

            
            <div class="form-group <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <label for="price">Per Unit Price</label>
              <input type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="price" name="price" placeholder="150" readonly="">
              <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block m-b-none danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <label for="quantity">Quantity</label>
              <input type="number" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="quantity" name="quantity" placeholder="150" required="">
              <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block m-b-none danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <label for="paid_amount">Paid Amount</label>
              <input type="number" class="form-control <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="paid_amount" name="paid_amount" placeholder="150" required="">
              <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block m-b-none danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <label for="date">Dated</label>
              <input type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date" name="date" placeholder="150" required="">
              <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block m-b-none danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group <?php $__errorArgs = ['total_bill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <label for="total_bill">Total Bill</label>
              <input type="number" class="form-control <?php $__errorArgs = ['total_bill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total_bill" name="total_bill" placeholder="150" readonly="">
              <?php $__errorArgs = ['total_bill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block m-b-none danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <?php if(count($customers)>0): ?>
            <div class="text-right">
              <button type="submit" class="btn primary m-b">Save Data</button>
            </div>
            <?php endif; ?>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  (function ($) {
  'use strict';
      var webhook = "<?php echo e(url('')); ?>";
      var price = null;
      $("#user_id").prop('disabled',true);
      $("#user_id").append("<option value='' selected=''>Select Customer</option>");
      $("#sector_id").on('change',function(){
        var id = $(this).val();
        if(id!=""){
          var  url = webhook+"/customers/filter/sector|"+id;
            $.get(url, function(data, status){
              console.log(data);
              if(status=="success"){
                if(data.customer.length>0){
                  $("#user_id").children("option").remove();
                  $("#user_id").prop("disabled",false);
                  $("#user_id").append("<option value='' selected=''>Select Customer</option>");
                  data.customer.forEach(function(value){
                    $("#user_id").append("<option value='"+value.id+"'>"+value.f_name+" "+value.l_name+"</option>");
                  });
                }
                else{
                  $("#user_id").prop('disabled',true);
                }
              }
            });
          }
      });

      $("#user_id").on('change',function(){
         var id = $(this).val();
          if(id!=""){
           var url = webhook+"/customers/filter/customer|"+id;
            $.get(url, function(data, status){
              console.log(data);
              if(status=="success"){
                price = data.customer.price;
                $("#price").val(price);
                $("#quantity").val(1);
                $("#paid_amount").val(price);
                $("#total_bill").val(price);
              }
            });
          }
        });
        $("#quantity").keyup(function(){
          if(price==null){
            swal({
              title: "Select Customer",
              text: "Customer is not yet selected. Kindly select the customer.",
              icon: "warning",
              button: true,
              dangerMode: true,
            });
          }
          else{
            var quantity = $(this).val();
            var total_bill = quantity * price;
            $("#total_bill").val(total_bill);
          }
        });
        $("#form-purchase").submit(function(e){
            var total_bill = $("#total_bill").val();
            var paid_amount = $("#paid_amount").val();
            if(paid_amount>total_bill){
                e.preventDefault(e);
                swal({
                title: "Paid Amount is large!",
                text: "Make sure your paid amount is equal or less than total billing amount.",
                icon: "warning",
                button: true,
                dangerMode: true,
              });
            }
        });
  })(jQuery);

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ButtSahab\waterplus-web-app\resources\views/pages/purchases/add.blade.php ENDPATH**/ ?>