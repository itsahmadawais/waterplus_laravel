

<?php $__env->startSection('content'); ?>
<div class="padding">
  <div class="box">
    <div class="box-header">
      <h2>Search Filter</h2>
    </div>
    <div class="box-divider m-0"></div>
        <div class="box-body p-v-md">
          <form class="form-inline" role="form" method="GET" action="<?php echo e(url('customers')); ?>">
            <div class="form-group mr-2">
              <select id="sector_id" class="form-control select2" ui-jp="select2" ui-options="{theme: 'bootstrap'}" name="sector_id">
                <option value="" disabled="" selected="">Select Sector</option>
                <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($sector->id); ?>"><?php echo e($sector->sector_title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group mr-2">
             <select id="debt" class="form-control mr-2" name="debt">
               <option value="" disabled="" selected="">Select Customers Type</option>
               <option value="debt">Debt</option>
               <option value="all">All</option>
             </select>
            <button type="submit" class="btn primary">Search</button>
          </form>
        </div>
    </div>

  <div class="box">
    <div class="box-header">
      <h2>Customers</h2>
    </div>
    <div class="table-responsive">
      <table id="DataTables" ui-jp="dataTable" class="table table-striped b-t b-b">
        <thead>
          <tr>
            <th  style="width:20%">Name</th>
            <th  style="width:25%">Phone</th>
            <th  style="width:25%">Email</th>
            <th  style="width:15%">Price</th>
            <th  style="width:15%" class="nosort"></th>
          </tr>
        </thead>
        <tbody>
        	<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><a href="<?php echo e(url('purchases/'.$customer->id)); ?>"><?php echo e($customer->f_name." ".$customer->l_name); ?></a></td>
            <td><?php echo e($customer->phone); ?></td>
            <td><?php echo e($customer->email); ?></td>
            <td>Rs <?php echo e($customer->price); ?></td>
            <td>
                <form method="POST" action="<?php echo e(url('customers/'.$customer->id)); ?>" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="md-btn md-raised red"><i class="fa fa-trash"></i></button>
                </form>
                <button class="md-btn md-raised blue"><i class="fa fa-pencil" onclick="moveToScreen('<?php echo e(url('customers/'.$customer->id)); ?>')"></i></button>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ButtSahab\waterplus-web-app\resources\views/pages/customers/all.blade.php ENDPATH**/ ?>