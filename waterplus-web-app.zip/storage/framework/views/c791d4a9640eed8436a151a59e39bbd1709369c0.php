

<?php $__env->startSection('content'); ?>
<div class="padding">
  <div class="row">
    <div class="col-md-12 mx-auto">
      <div class="box">
        <div class="box-header">
          <h2>Custom Report Generator</h2>
        </div>
        <div class="box-divider m-0"></div>
        <div class="box-body">
          <form role="form" method="POST" action="<?php echo e(url('custom-revenue')); ?>">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="col-md-6">
                    
                    <div class="form-group <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="start_date">Start Date</label>
                        <input type="date" class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="start_date" name="start_date" required>
                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block m-b-none danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    
                    <div class="form-group <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="end_date">Start Date</label>
                        <input type="date" class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="end_date" name="end_date" required>
                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block m-b-none danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="text-right">
              <button type="submit" class="btn primary m-b">Save and continue</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <?php if($data==true): ?>
  <div class="row">
    <div class="col-xs-6 col-sm-3">
      <div class="box p-a">
        <div class="pull-left m-r">
          <span class="w-48 rounded  accent">
            <i class="fa fa-money"></i>
          </span>
        </div>
        <div class="clear">
          <h4 class="m-0 text-lg _300"><a href>Rs <?php echo e($profit); ?></span></a></h4>
          <small class="text-muted">Profit</small>
        </div>
      </div>
  </div>
  <div class="col-xs-6 col-sm-3">
      <div class="box p-a">
        <div class="pull-left m-r">
          <span class="w-48 rounded primary">
            <i class="fa fa-money"></i>
          </span>
        </div>
        <div class="clear">
          <h4 class="m-0 text-lg _300"><a href>Rs <?php echo e($profit_with_debt); ?></span></a></h4>
          <small class="text-muted">Cash in hand</small>
        </div>
      </div>
  </div>
<div class="col-xs-6 col-sm-3">
    <div class="box p-a">
      <div class="pull-left m-r">
        <span class="w-48 rounded warn">
          <i class="fa fa-money"></i>
        </span>
      </div>
      <div class="clear">
        <h4 class="m-0 text-lg _300"><a href>Rs <?php echo e($quantity_sold); ?></span></a></h4>
        <small class="text-muted">Quantity sold</small>
      </div>
    </div>
</div>
  <div class="col-xs-6 col-sm-3">
      <div class="box p-a">
        <div class="pull-left m-r">
          <span class="w-48 rounded warn">
            <i class="fa fa-money"></i>
          </span>
        </div>
        <div class="clear">
          <h4 class="m-0 text-lg _300"><a href><?php echo e($expense_amount); ?></span></a></h4>
          <small class="text-muted">Expense</small>
        </div>
      </div>
  </div>
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ButtSahab\waterplus-web-app\resources\views/pages/custom-reveneue-filter.blade.php ENDPATH**/ ?>