

<?php $__env->startSection('content'); ?>
<div class="padding">
  <div class="box">
    <div class="box-header">
      <h2>Search Filter</h2>
    </div>
    <div class="box-divider m-0"></div>
        <div class="box-body p-v-md">
          <form class="form-inline" role="form" method="POST" action="<?php echo e(url('pdf/customer')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden"
            id="customer_id"
            name="customer_id"
            value="<?php echo e($customer->id); ?>">
            <div class="form-group mr-2">
              <label class="mr-2 sr-end">Start Date</label>
              <input type="date" 
              name="start_date"
              class="form-control" 
              id="start_date"
              required="">
            </div>
            <div class="form-group mr-2">
              <label class="mr-2 sr-end">End Date</label>
              <input type="date" 
              name="end_date"
              class="form-control" 
              id="end_date"
              required="">
            </div>
            <div class="form-group mr-2">
             <select id="transaction" class="form-control mr-2" name="transaction" required="">
               <option value="" disabled="" selected="">Transaction Type</option>
               <option value="debt">Debt</option>
               <option value="all">All</option>
             </select>
            <button type="submit" class="btn primary">Generate PDF</button>
          </form>
        </div>
    </div>
  <div class="box">
    <div class="box-header">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <h2><?php echo e($customer->f_name." ".$customer->l_name); ?></h2>
            <hr>
            <h2>Debt: Rs <?php echo e($debt->amount); ?></h2>
          </div>
          <div class="col-md-8 text-right">
            <?php if(auth()->user()->role=="admin"): ?>
            <button class="btn info" data-toggle="modal" data-target="#m-a-f">Pay Debit</button>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
    <div class="table-responsive">
      <table id="DataTables" ui-jp="dataTable" class="table table-striped b-t b-b">
        <thead>
          <tr>
            <th  style="width:15%">Type</th>
            <th  style="width:15%">Paid Amount</th>
            <th  style="width:15%">Price Per Unit</th>
            <th  style="width:10%">Quantity</th>
            <th  style="width:15%">Total Bill</th>
            <th  style="width:15%">Dated</th>
            <?php if(auth()->guard()->check()): ?>
              <?php if(auth()->user()->role=="admin"): ?>
              <th  style="width:15%" class="nosort"></th>
              <?php endif; ?>
            <?php endif; ?>
          </tr>
        </thead>
        <tbody>
        	<?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <?php if($purchase->type=="purchased"): ?>
                <span class="label label-sm success pos-rlt m-r-xs"><b class="arrow left b-success"></b>Purchased</span>
              <?php else: ?>
                <span class="label label-sm danger pos-rlt m-r-xs"><b class="arrow left b-danger"></b>Debt Paid</span>
              <?php endif; ?>
            </td>
            <td>Rs <?php echo e($purchase->paid_amount); ?></td>
            <td>
              <?php if($purchase->type=="purchased"): ?>
                <?php echo e($purchase->per_unit_price); ?>

              <?php else: ?>
                ---
              <?php endif; ?>
            </td>
            <td>
              <?php if($purchase->type=="purchased"): ?>
                <?php echo e($purchase->quantity); ?>

              <?php else: ?>
                ---
              <?php endif; ?>
            </td>
            <td>
              <?php if($purchase->type=="purchased"): ?>
                <?php echo e($purchase->total_bill); ?>

              <?php else: ?>
                ---
              <?php endif; ?>
            </td>
            <td><?php echo e(date('d M, Y',strtotime($purchase->created_at))); ?></td>
            <?php if(auth()->guard()->check()): ?>
              <?php if(auth()->user()->role=="admin"): ?>
              <td>
                  <form method="POST" action="<?php echo e(url('purchases/'.$purchase->id)); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="md-btn md-raised red"><i class="fa fa-trash"></i></button>
                  </form>
              </td>
              <?php endif; ?>
            <?php endif; ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div id="m-a-f" class="modal fade show" data-backdrop="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Pay Debt</h5>
      </div>
      <form method="POST" action="<?php echo e(url('debt')); ?>">
      <?php echo method_field('PUT'); ?>
      <?php echo csrf_field(); ?>
      <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
      <div class="modal-body p-lg">
        <div class="form-group">
          <label for="debt_amount">Pay Amount</label>
          <input type="number" class="form-control" id="debt_amount" name="debt_amount" value="0" min="1" max="<?php echo e($debt->amount); ?>" placeholder="150" required="">
        </div>
        <div class="form-group">
          <label for="remaining_debt">Remaining Debt</label>
          <input type="number" class="form-control" id="remaining_debt" name="remaining_debt" placeholder="150" value="<?php echo e($debt->amount); ?>" readonly="">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn dark-white p-x-md" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn danger p-x-md">Pay Amount</button>
      </div>
    </form>
    </div><!-- /.modal-content -->
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  (function ($) {
  'use strict';
      $("#debt_amount").keyup(function(){
          var debt_amount = "<?php echo e($debt->amount); ?>";
          var debt = $(this).val();
          var difference = debt_amount-debt;
          if(difference<0){
            swal({
                title: "Wrong Debt Amount!",
                text: "Make sure your debt amount is less than or equal to Rs "+debt_amount,
                icon: "warning",
                button: true,
                dangerMode: true,
              });
            $("#debt_amount").val(0);
            $("#remaining_debt").val(debt_amount);
            return;
          }
          $("#remaining_debt").val(difference);
      });
  })(jQuery);

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ButtSahab\waterplus-web-app\resources\views/pages/purchases/records.blade.php ENDPATH**/ ?>